import React, { useState } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { GamificationProfile, HistoryItem } from '../types';
import { FireIcon, SparklesIcon, TargetIcon, TrophyIcon, PlayIcon, SettingsIcon } from '../components/Icons';
import TopicDonutChart from '../components/charts/TopicDonutChart';
import AchievementBadge from '../components/AchievementBadge';
import { ALL_ACHIEVEMENTS } from '../services/achievements';
import WeeklyActivityChart from '../components/charts/WeeklyActivityChart';
import { processHistoryForActivityChart } from '../utils/chartUtils';
import CodePlayground from '../components/CodePlayground';
import { triggerHapticFeedback } from '../utils/haptics';
import ThemeSelectorModal from '../components/ThemeSelectorModal';
import { ThemeID } from '../themes';

const defaultProfile: GamificationProfile = {
    totalXP: 0,
    streak: 0,
    lastActiveDate: null,
    unlockedAchievements: [],
};

interface PlaygroundCode {
    code: string;
    language: string;
}

const LearnScreen: React.FC = () => {
    const [profile] = useLocalStorage<GamificationProfile>('wave-profile', defaultProfile);
    const [history] = useLocalStorage<HistoryItem[]>('wave-history', []);
    const [playgroundCode, setPlaygroundCode] = useState<PlaygroundCode | null>(null);
    const [isThemeModalOpen, setIsThemeModalOpen] = useState(false);
    const [currentTheme, setCurrentTheme] = useLocalStorage<ThemeID>('wave-theme', 'default');
    
    const weeklyGoalXP = 70;
    const weeklyProgress = Math.min((profile.totalXP % weeklyGoalXP) / weeklyGoalXP * 100, 100);

    const topicCounts = history.reduce((acc, item) => {
        const lang = item.language_detected || 'Other';
        acc[lang] = (acc[lang] || 0) + 1;
        return acc;
    }, {} as Record<string, number>);

    const topicData = Object.entries(topicCounts).map(([label, value], index) => {
        const colors = ['#4DB6AC', '#81C784', '#A5D6A7', '#FFB74D', '#FF8A65'];
        return { label, value, color: colors[index % colors.length] };
    }).sort((a,b) => b.value - a.value).slice(0, 5);

    const activityData = processHistoryForActivityChart(history);

    const recentCodeExamples = history
        .flatMap(item => item.examples.map(ex => ({ ...ex, language: item.language_detected })))
        .slice(0, 5);
        
    const handleOpenThemeModal = () => {
        triggerHapticFeedback();
        setIsThemeModalOpen(true);
    }

    const StatCard: React.FC<{ icon: React.ReactNode, title: string, value: string | number, color: string }> = ({ icon, title, value, color }) => (
        <div className="glass-card p-4 rounded-2xl flex items-center space-x-4">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center ${color}`}>
                {icon}
            </div>
            <div>
                <p className="text-gray-500 text-sm">{title}</p>
                <p className="font-bold text-2xl text-gray-800">{value}</p>
            </div>
        </div>
    );

    const Section: React.FC<{title: string, icon?: React.ReactNode, children: React.ReactNode}> = ({title, icon, children}) => (
        <div className="glass-card p-5 rounded-2xl mb-6">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center">
                {icon}
                {title}
            </h3>
            {children}
        </div>
    );

    return (
        <>
            {playgroundCode && (
                <CodePlayground 
                    initialCode={playgroundCode.code}
                    language={playgroundCode.language}
                    onClose={() => setPlaygroundCode(null)}
                />
            )}

            <ThemeSelectorModal
                isOpen={isThemeModalOpen}
                onClose={() => setIsThemeModalOpen(false)}
                currentThemeId={currentTheme}
                onThemeSelect={setCurrentTheme}
            />

            <div className="p-4 pt-10">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-3xl font-bold text-gray-800">Your Journey</h2>
                    <button
                        onClick={handleOpenThemeModal}
                        className="p-2 rounded-full text-gray-500 hover:bg-gray-200/50 transition-colors haptic-press"
                    >
                        <SettingsIcon className="w-6 h-6"/>
                    </button>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-6">
                    <StatCard icon={<FireIcon className="w-7 h-7 text-white"/>} title="Day Streak" value={profile.streak} color="bg-orange-400" />
                    <StatCard icon={<SparklesIcon className="w-7 h-7 text-white"/>} title="Total XP" value={profile.totalXP} color="bg-teal-400" />
                </div>

                <Section title="Weekly Goal" icon={<TargetIcon className="w-5 h-5 mr-2 text-rose-500"/>}>
                    <div className="flex justify-between items-center mb-2">
                         <p className="font-semibold text-sm text-gray-600">Current Progress</p>
                        <p className="font-semibold text-sm text-[var(--primary-glow)]">{profile.totalXP % weeklyGoalXP} / {weeklyGoalXP} XP</p>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                        <div className="bg-gradient-to-r from-[var(--secondary-glow)] to-[var(--primary-glow)] h-3 rounded-full transition-all duration-500" style={{ width: `${weeklyProgress}%`,  boxShadow: '0 0 8px var(--primary-glow)' }}></div>
                    </div>
                </Section>
                
                <Section title="Weekly Activity">
                    <WeeklyActivityChart activityData={activityData} />
                </Section>
                
                {recentCodeExamples.length > 0 && (
                     <Section title="Code Playground">
                        <div className="space-y-3">
                            {recentCodeExamples.map((example, index) => (
                                <div key={index} className="bg-gray-50 p-3 rounded-lg flex justify-between items-center">
                                    <div className="flex-1 overflow-hidden">
                                        <p className="text-sm text-gray-700 truncate font-mono">{example.comment}</p>
                                        <p className="text-xs text-gray-500">{example.language}</p>
                                    </div>
                                    <button 
                                        onClick={() => {
                                            triggerHapticFeedback();
                                            setPlaygroundCode({code: example.code, language: example.language})
                                        }}
                                        className="ml-4 bg-teal-100 text-teal-700 font-semibold text-xs px-3 py-1.5 rounded-full flex items-center hover:bg-teal-200 transition-colors haptic-press transform hover:scale-105">
                                        <PlayIcon className="w-4 h-4 mr-1"/>
                                        Try it
                                    </button>
                                </div>
                            ))}
                        </div>
                    </Section>
                )}


                {topicData.length > 0 &&
                    <Section title="Topic Focus">
                        <TopicDonutChart data={topicData} />
                    </Section>
                }
                
                <Section title="Achievements" icon={<TrophyIcon className="w-5 h-5 mr-2 text-amber-500"/>}>
                     <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {ALL_ACHIEVEMENTS.map(ach => (
                            <AchievementBadge 
                                key={ach.id}
                                achievement={ach}
                                isUnlocked={profile.unlockedAchievements.includes(ach.id)}
                            />
                        ))}
                     </div>
                </Section>
            </div>
        </>
    );
};

export default LearnScreen;