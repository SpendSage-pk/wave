import React, { useState } from 'react';
import { CameraIcon, LearnIcon, SparklesIcon } from '../components/Icons';
import { triggerHapticFeedback } from '../utils/haptics';

interface OnboardingScreenProps {
  onComplete: () => void;
}

const onboardingSteps = [
  {
    icon: (props: any) => <h1 {...props} className="text-white text-5xl font-bold">W</h1>,
    title: 'Welcome to Wave',
    description: 'Turn any piece of code, screenshot, or note into an interactive learning session.',
    bgColor: 'bg-gradient-to-br from-[#4DB6AC] to-[#81C784]',
  },
  {
    icon: CameraIcon,
    title: 'Snap or Upload',
    description: 'Start by taking a picture of code or uploading an image from your gallery. Wave handles the rest.',
    bgColor: 'bg-[#A5D6A7]',
  },
  {
    icon: SparklesIcon,
    title: 'Instant AI Analysis',
    description: 'Our AI provides step-by-step explanations, examples, and real-world scenarios to deepen your understanding.',
    bgColor: 'bg-[#81C784]',
  },
  {
    icon: LearnIcon,
    title: 'Track Your Journey',
    description: "Visit the 'Learn' tab to see your progress, track your streak, and unlock achievements as you go.",
    bgColor: 'bg-[#4DB6AC]',
  },
];

const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);

  const handleNext = () => {
    triggerHapticFeedback();
    if (currentStep < onboardingSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const step = onboardingSteps[currentStep];
  const Icon = step.icon;

  return (
    <div className="fixed inset-0 bg-[#F9FBF8] z-50 flex flex-col p-8 justify-between text-center animate-fade-in">
      <div>
        <div className={`w-24 h-24 ${step.bgColor} rounded-3xl shadow-lg flex items-center justify-center mx-auto mb-8 transition-colors duration-500`}>
          <Icon className="w-12 h-12 text-white" />
        </div>
        <h2 className="text-3xl font-bold text-gray-800 mb-3">{step.title}</h2>
        <p className="text-gray-600 max-w-sm mx-auto">{step.description}</p>
      </div>

      <div className="flex items-center justify-center space-x-2 mb-8">
        {onboardingSteps.map((_, index) => (
          <div
            key={index}
            className={`w-2 h-2 rounded-full transition-all duration-300 ${
              index === currentStep ? 'bg-[#4DB6AC] w-4' : 'bg-gray-300'
            }`}
          />
        ))}
      </div>

      <button
        onClick={handleNext}
        className="w-full max-w-xs mx-auto bg-gradient-to-r from-[#4DB6AC] to-[#81C784] text-white font-bold py-4 px-6 rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
      >
        {currentStep === onboardingSteps.length - 1 ? "Let's Go!" : 'Continue'}
      </button>
    </div>
  );
};

export default OnboardingScreen;