import React, { useState } from 'react';
import { HistoryItem } from '../types';
import { useLocalStorage } from '../hooks/useLocalStorage';
import ResultDisplay from './ResultDisplay';
import CodePlayground from '../components/CodePlayground';
import { triggerHapticFeedback } from '../utils/haptics';

interface PlaygroundCode {
    code: string;
    language: string;
}

const HistoryScreen: React.FC = () => {
  const [history, setHistory] = useLocalStorage<HistoryItem[]>('wave-history', []);
  const [selectedItem, setSelectedItem] = useState<HistoryItem | null>(null);
  const [playgroundCode, setPlaygroundCode] = useState<PlaygroundCode | null>(null);

  const clearHistory = () => {
    triggerHapticFeedback();
    setHistory([]);
    setSelectedItem(null);
  }

  const handleFeedbackSubmit = (feedback: { status: 'like' | 'dislike'; comment: string }) => {
    if (!selectedItem) return;

    const updatedItem: HistoryItem = {
        ...selectedItem,
        feedback: feedback.status,
        feedbackComment: feedback.comment,
    };

    setSelectedItem(updatedItem);
    setHistory(prev => prev.map(item =>
        item.id === selectedItem.id ? updatedItem : item
    ));
  };

  const handleSelectItem = (item: HistoryItem) => {
    triggerHapticFeedback();
    setSelectedItem(item);
  };
  
  const handleBack = () => {
    triggerHapticFeedback();
    setSelectedItem(null);
  }

  if (selectedItem) {
    return (
      <>
        {playgroundCode && (
            <CodePlayground 
                initialCode={playgroundCode.code}
                language={playgroundCode.language}
                onClose={() => setPlaygroundCode(null)}
            />
        )}
        <div className="animate-fade-in">
          <div className="p-4 pt-10">
            <button
              onClick={handleBack}
              className="w-full text-left font-semibold text-[var(--primary-glow)] flex items-center p-2 rounded-lg hover:bg-gray-200/50 transition-colors haptic-press"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              Back to History
            </button>
          </div>
          <ResultDisplay 
            result={selectedItem} 
            onOpenInPlayground={(code, language) => setPlaygroundCode({ code, language })}
            feedbackState={{
                status: selectedItem.feedback,
                comment: selectedItem.feedbackComment,
            }}
            onFeedbackSubmit={handleFeedbackSubmit}
          />
        </div>
      </>
    );
  }

  return (
    <div className="p-4 pt-10">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">History</h2>
        {history.length > 0 && (
            <button onClick={clearHistory} className="text-sm font-medium text-red-500 hover:text-red-700 haptic-press">
                Clear All
            </button>
        )}
      </div>
      
      {history.length === 0 ? (
        <div className="text-center py-20">
            <div className="w-20 h-20 bg-gray-100 rounded-full mx-auto flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 13h6m-3-3v6m-9 1V7a2 2 0 012-2h4l2 2h4a2 2 0 012 2v10a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
                </svg>
            </div>
            <h3 className="mt-4 text-lg font-semibold text-gray-700">No History Yet</h3>
            <p className="text-gray-500 mt-1">Your analyzed images will appear here.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {history.map((item) => (
            <div
              key={item.id}
              onClick={() => handleSelectItem(item)}
              className="bg-white/50 rounded-2xl shadow-sm p-4 flex items-center space-x-4 cursor-pointer hover:shadow-md hover:bg-white/80 transition-all duration-300 animate-fade-in haptic-press"
            >
              <img src={item.imagePreview} alt="Analyzed content" className="w-16 h-16 rounded-lg object-cover flex-shrink-0 bg-gray-100" />
              <div className="flex-1 overflow-hidden">
                <h3 className="font-bold text-gray-800 truncate">{item.title}</h3>
                <p className="text-sm text-gray-500">{item.language_detected}</p>
                <p className="text-xs text-gray-400 mt-1">{new Date(item.timestamp).toLocaleString()}</p>
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default HistoryScreen;