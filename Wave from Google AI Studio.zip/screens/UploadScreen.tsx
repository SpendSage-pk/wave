import React, { useState, useRef } from 'react';
import { analyzeImage } from '../services/geminiService';
import { AnalysisResult, HistoryItem, GamificationProfile, Achievement } from '../types';
import Loader from '../components/Loader';
import ResultDisplay from './ResultDisplay';
import { CameraIcon, SparklesIcon } from '../components/Icons';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { getISODateString, isToday, isYesterday } from '../utils/dateUtils';
import { checkAndUnlockAchievements, ALL_ACHIEVEMENTS } from '../services/achievements';
import AchievementUnlockedModal from '../components/AchievementUnlockedModal';
import CodePlayground from '../components/CodePlayground';
import { triggerHapticFeedback } from '../utils/haptics';

const fileToDataUri = (file: File): Promise<{base64: string, dataUri: string}> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
        const dataUri = event.target?.result as string;
        const base64 = dataUri.split(',')[1];
        resolve({ base64, dataUri });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
});

const defaultProfile: GamificationProfile = {
    totalXP: 0,
    streak: 0,
    lastActiveDate: null,
    unlockedAchievements: [],
};

interface PlaygroundCode {
    code: string;
    language: string;
}

const UploadScreen: React.FC = () => {
    const [imagePreview, setImagePreview] = useState<string | null>(null);
    const [imageBase64, setImageBase64] = useState<string | null>(null);
    const [imageMimeType, setImageMimeType] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [result, setResult] = useState<AnalysisResult | null>(null);
    const [history, setHistory] = useLocalStorage<HistoryItem[]>('wave-history', []);
    const [profile, setProfile] = useLocalStorage<GamificationProfile>('wave-profile', defaultProfile);
    const [unlockedAchievementsToShow, setUnlockedAchievementsToShow] = useState<Achievement[]>([]);
    const [playgroundCode, setPlaygroundCode] = useState<PlaygroundCode | null>(null);
    const [latestAnalysisId, setLatestAnalysisId] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    
    const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            setResult(null);
            setError(null);
            try {
                const { base64, dataUri } = await fileToDataUri(file);
                setImagePreview(dataUri);
                setImageBase64(base64);
                setImageMimeType(file.type);
            } catch (err) {
                setError("Failed to read the image file.");
            }
        }
    };

    const handleAnalyze = async () => {
        triggerHapticFeedback();
        if (!imageBase64 || !imageMimeType) {
            setError("No image data available to analyze.");
            return;
        }
        setIsLoading(true);
        setError(null);
        setResult(null);

        try {
            const analysisResult = await analyzeImage(imageBase64, imageMimeType);
            setResult(analysisResult);

            const newHistoryItem: HistoryItem = {
                ...analysisResult,
                id: new Date().toISOString(),
                timestamp: new Date().toISOString(),
                imagePreview: imagePreview!,
            };
            
            setLatestAnalysisId(newHistoryItem.id);

            setHistory(prevHistory => {
                const newHistory = [newHistoryItem, ...prevHistory.slice(0, 49)];
                
                setProfile(prevProfile => {
                    const todayStr = getISODateString(new Date());
                    let newStreak = prevProfile.streak;

                    if (prevProfile.lastActiveDate) {
                        if (isYesterday(prevProfile.lastActiveDate)) {
                            newStreak += 1;
                        } else if (!isToday(prevProfile.lastActiveDate)) {
                            newStreak = 1;
                        }
                    } else {
                        newStreak = 1;
                    }

                    const updatedProfile: GamificationProfile = {
                        ...prevProfile,
                        totalXP: prevProfile.totalXP + 10,
                        streak: newStreak,
                        lastActiveDate: todayStr,
                    };
                    
                    const newlyUnlockedIds = checkAndUnlockAchievements(newHistory, updatedProfile);
                    if(newlyUnlockedIds.length > 0) {
                        updatedProfile.unlockedAchievements = [...new Set([...prevProfile.unlockedAchievements, ...newlyUnlockedIds])];
                        const newAchievements = ALL_ACHIEVEMENTS.filter(ach => newlyUnlockedIds.includes(ach.id));
                        setUnlockedAchievementsToShow(newAchievements);
                    }

                    return updatedProfile;
                });

                return newHistory;
            });

        } catch (err: any) {
            setError(err.message || "An unknown error occurred.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleFeedbackSubmit = (feedback: { status: 'like' | 'dislike'; comment: string }) => {
        if (!latestAnalysisId) return;
        setHistory(prev => prev.map(item =>
            item.id === latestAnalysisId
                ? { ...item, feedback: feedback.status, feedbackComment: feedback.comment }
                : item
        ));
    };

    const triggerFileSelect = () => {
        triggerHapticFeedback();
        fileInputRef.current?.click();
    }
    
    const resetState = () => {
        triggerHapticFeedback();
        setImagePreview(null);
        setImageBase64(null);
        setImageMimeType(null);
        setIsLoading(false);
        setError(null);
        setResult(null);
        setPlaygroundCode(null);
        setLatestAnalysisId(null);
        if(fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    }

    const closeAchievementModal = () => {
        setUnlockedAchievementsToShow(prev => prev.slice(1));
    };

    const currentHistoryItem = history.find(item => item.id === latestAnalysisId);

    return (
        <div className="p-4 pt-10">
            <AchievementUnlockedModal 
                achievements={unlockedAchievementsToShow}
                onClose={closeAchievementModal}
            />

            {playgroundCode && (
                <CodePlayground 
                    initialCode={playgroundCode.code}
                    language={playgroundCode.language}
                    onClose={() => setPlaygroundCode(null)}
                />
            )}

            {!imagePreview && !isLoading && !result && (
                 <div className="flex flex-col items-center justify-center h-[calc(100vh-10rem)] text-center">
                    <h2 className="text-2xl font-bold text-gray-800">Upload Your Code</h2>
                    <p className="text-gray-500 mt-2 mb-8 max-w-sm">Snap a photo, upload a screenshot, or select any image to get started.</p>
                    <div
                        className="w-full max-w-md h-48 border-2 border-dashed border-[var(--accent-glow)] rounded-2xl flex flex-col items-center justify-center bg-white/50 cursor-pointer hover:border-[var(--primary-glow)] hover:scale-105 transition-all duration-300 group"
                        onClick={triggerFileSelect}
                    >
                        <CameraIcon className="w-12 h-12 text-[var(--secondary-glow)] group-hover:text-[var(--primary-glow)] transition-colors" />
                        <p className="mt-2 font-semibold text-gray-700">Tap to upload</p>
                        <p className="text-xs text-gray-500">JPG, PNG, WEBP</p>
                    </div>
                </div>
            )}
            
            <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                capture="environment"
                className="hidden"
            />
            
            {imagePreview && !isLoading && !result && (
                <div className="flex flex-col items-center animate-fade-in">
                    <h2 className="text-xl font-semibold mb-4 text-center">Ready to Analyze?</h2>
                    <div className="w-full max-w-md rounded-2xl shadow-lg overflow-hidden mb-6 border-2 border-white">
                        <img src={imagePreview} alt="Code preview" className="w-full object-contain" />
                    </div>
                    <div className="flex space-x-4">
                        <button
                            onClick={triggerFileSelect}
                            className="bg-gray-200 text-gray-800 font-bold py-3 px-6 rounded-xl hover:bg-gray-300 transition-all duration-300 haptic-press"
                        >
                            Change
                        </button>
                        <button
                            onClick={handleAnalyze}
                            className="bg-gradient-to-r from-[#4DB6AC] to-[#81C784] text-white font-bold py-3 px-8 rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-300 flex items-center haptic-press"
                        >
                           <SparklesIcon className="w-5 h-5 mr-2"/>
                            Analyze
                        </button>
                    </div>
                </div>
            )}
            
            {isLoading && <Loader message="Analyzing your image..." />}
            
            {error && (
                <div className="text-center p-6 bg-red-100 border border-red-300 rounded-xl text-red-700">
                    <h3 className="font-bold">Oops! Something went wrong.</h3>
                    <p className="text-sm mt-1">{error}</p>
                    <button onClick={resetState} className="mt-4 bg-red-500 text-white font-semibold py-2 px-4 rounded-lg text-sm haptic-press">
                        Try Again
                    </button>
                </div>
            )}

            {result && (
                <div className="animate-fade-in">
                    <ResultDisplay 
                        result={result} 
                        onOpenInPlayground={(code, language) => setPlaygroundCode({ code, language })}
                        feedbackState={{
                            status: currentHistoryItem?.feedback,
                            comment: currentHistoryItem?.feedbackComment,
                        }}
                        onFeedbackSubmit={handleFeedbackSubmit}
                    />
                     <button onClick={resetState} className="mt-4 w-full bg-gray-700 text-white font-semibold py-3 px-4 rounded-xl text-sm hover:bg-gray-800 transition-colors haptic-press">
                        Analyze Another Image
                    </button>
                </div>
            )}

        </div>
    );
};

export default UploadScreen;