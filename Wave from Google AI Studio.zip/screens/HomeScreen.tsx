import React from 'react';
import { Tab } from '../types';
import { SparklesIcon } from '../components/Icons';
import { triggerHapticFeedback } from '../utils/haptics';

interface HomeScreenProps {
    setActiveTab: (tab: Tab) => void;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ setActiveTab }) => {
    return (
        <div className="p-6 pt-16 h-full flex flex-col justify-center text-center">
            <div className="flex justify-center items-center mb-6">
                <div className="w-24 h-24 bg-gradient-to-br from-[#4DB6AC] to-[#81C784] rounded-3xl shadow-lg flex items-center justify-center animate-pulse">
                    <h1 className="text-white text-5xl font-bold">W</h1>
                </div>
            </div>
            <h2 className="text-3xl font-bold text-gray-800">Welcome to Wave</h2>
            <p className="text-gray-600 mt-2 max-w-md mx-auto">
                Turn any code, screenshot, or handwritten note into a structured learning session.
            </p>

            <div className="mt-12 space-y-4">
                <div className="glass-card p-5 rounded-2xl text-left flex items-start space-x-4">
                    <div className="bg-[#A5D6A7]/30 text-[#4DB6AC] p-3 rounded-full">
                        <SparklesIcon className="w-6 h-6"/>
                    </div>
                    <div>
                        <h3 className="font-semibold text-gray-800">Instant Analysis</h3>
                        <p className="text-gray-500 text-sm">Get step-by-step explanations, examples, and more from a single image.</p>
                    </div>
                </div>
                 <div className="glass-card p-5 rounded-2xl text-left flex items-start space-x-4">
                    <div className="bg-[#A5D6A7]/30 text-[#4DB6AC] p-3 rounded-full">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5v-4m0 0h-4m4 0l-5-5" />
                        </svg>
                    </div>
                    <div>
                        <h3 className="font-semibold text-gray-800">Save & Revisit</h3>
                        <p className="text-gray-500 text-sm">Your analysis history is saved on your device for you to review anytime.</p>
                    </div>
                </div>
            </div>

            <div className="mt-16">
                 <button
                    onClick={() => {
                        triggerHapticFeedback();
                        setActiveTab('Upload');
                    }}
                    className="w-full max-w-xs mx-auto bg-gradient-to-r from-[#4DB6AC] to-[#81C784] text-white font-bold py-4 px-6 rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 haptic-press neon-glow-button"
                >
                    Start Learning
                </button>
            </div>
        </div>
    );
};

export default HomeScreen;