import React, { useState, useEffect } from 'react';
import { AnalysisResult } from '../types';
import CodeBlock from '../components/CodeBlock';
import { PlayIcon, ThumbUpIcon, ThumbDownIcon } from '../components/Icons';
import { triggerHapticFeedback } from '../utils/haptics';

interface ResultDisplayProps {
  result: AnalysisResult;
  onOpenInPlayground: (code: string, language: string) => void;
  feedbackState?: {
    status?: 'like' | 'dislike';
    comment?: string;
  };
  onFeedbackSubmit: (feedback: { status: 'like' | 'dislike'; comment: string }) => void;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ result, onOpenInPlayground, feedbackState, onFeedbackSubmit }) => {
  const [tempStatus, setTempStatus] = useState(feedbackState?.status);
  const [tempComment, setTempComment] = useState(feedbackState?.comment || '');

  useEffect(() => {
    setTempStatus(feedbackState?.status);
    setTempComment(feedbackState?.comment || '');
  }, [feedbackState]);

  const handleStatusChange = (status: 'like' | 'dislike') => {
    triggerHapticFeedback();
    setTempStatus(status);
  };

  const handleSubmit = () => {
    if (tempStatus) {
        triggerHapticFeedback();
        onFeedbackSubmit({ status: tempStatus, comment: tempComment });
        // Optionally show a "Thanks for your feedback!" message
    }
  };
  
  const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="glass-card rounded-2xl p-5 mb-4">
      <h3 className="text-lg font-bold text-[var(--primary-glow)] mb-3">{title}</h3>
      {children}
    </div>
  );

  const FeedbackSection = () => (
    <div className="glass-card rounded-2xl p-5 mt-4">
        <h3 className="text-base font-bold text-gray-700 mb-3 text-center">Was this explanation helpful?</h3>
        <div className="flex justify-center space-x-4 mb-4">
            <button
                onClick={() => handleStatusChange('like')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-full border-2 transition-all duration-300 transform hover:scale-105 haptic-press ${
                    tempStatus === 'like' ? 'bg-teal-100 border-teal-500 text-teal-700' : 'border-gray-300 text-gray-500 hover:bg-gray-100'
                }`}
            >
                <ThumbUpIcon className="w-5 h-5" />
                <span>Helpful</span>
            </button>
            <button
                onClick={() => handleStatusChange('dislike')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-full border-2 transition-all duration-300 transform hover:scale-105 haptic-press ${
                    tempStatus === 'dislike' ? 'bg-red-100 border-red-500 text-red-700' : 'border-gray-300 text-gray-500 hover:bg-gray-100'
                }`}
            >
                <ThumbDownIcon className="w-5 h-5" />
                <span>Not Helpful</span>
            </button>
        </div>
        {tempStatus && (
            <div className="animate-fade-in">
                <textarea
                    value={tempComment}
                    onChange={(e) => setTempComment(e.target.value)}
                    placeholder="Any other feedback? (optional)"
                    className="w-full p-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-[var(--primary-glow)] focus:border-[var(--primary-glow)] transition bg-white/50"
                    rows={3}
                />
                <button
                    onClick={handleSubmit}
                    className="w-full mt-2 bg-[var(--primary-glow)] text-white font-semibold py-2 px-4 rounded-lg text-sm hover:opacity-90 transition-opacity disabled:bg-gray-400 haptic-press"
                    disabled={feedbackState?.status === tempStatus && feedbackState?.comment === tempComment}
                >
                    Submit Feedback
                </button>
            </div>
        )}
    </div>
  );

  return (
    <div className="p-4 animate-fade-in">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">{result.title}</h2>
        <p className="text-sm text-white bg-[var(--secondary-glow)] inline-block px-3 py-1 rounded-full mt-2 font-medium shadow-md">
          {result.language_detected}
        </p>
      </div>

      <Section title="Summary">
        <p className="text-gray-600 leading-relaxed">{result.summary}</p>
      </Section>

      <Section title="Step-by-Step Explanation">
        <div className="space-y-4">
          {result.explanation.map((step, index) => (
            <div key={index} className="flex items-start">
              <div className="flex-shrink-0 w-8 h-8 bg-[var(--accent-glow)]/50 text-[var(--primary-glow)] font-bold text-sm rounded-full flex items-center justify-center mr-4 mt-1 ring-2 ring-white">
                {index + 1}
              </div>
              <p className="text-gray-700 leading-relaxed">{step}</p>
            </div>
          ))}
        </div>
      </section>

      <Section title="Examples">
        {result.examples.map((example, index) => (
          <div key={index} className="mb-4">
            <div className="flex justify-between items-start mb-2">
              <p className="text-gray-700 mr-4 flex-1">{example.comment}</p>
              <button
                  onClick={() => {
                      triggerHapticFeedback();
                      onOpenInPlayground(example.code, result.language_detected);
                  }}
                  className="flex-shrink-0 ml-4 bg-teal-100 text-teal-700 font-semibold text-xs px-3 py-1.5 rounded-full flex items-center hover:bg-teal-200 transition-colors haptic-press transform hover:scale-105"
              >
                  <PlayIcon className="w-4 h-4 mr-1"/>
                  Try it
              </button>
            </div>
            <CodeBlock code={example.code} language={result.language_detected} />
          </div>
        ))}
      </section>

      <Section title="Real-World Scenarios">
        <ul className="list-disc list-inside space-y-2 text-gray-700">
          {result.scenarios.map((scenario, index) => (
            <li key={index}>{scenario}</li>
          ))}
        </ul>
      </section>

      <Section title="Execution Flow">
        <ol className="list-decimal list-inside space-y-2 text-gray-700">
          {result.execution_flow.map((flow, index) => (
            <li key={index}>{flow}</li>
          ))}
        </ol>
      </section>

      <FeedbackSection />
    </div>
  );
};

export default ResultDisplay;