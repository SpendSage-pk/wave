import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // This is a fallback for development and will be replaced by the environment
  console.warn("API_KEY is not set in environment variables.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const model = 'gemini-2.5-flash';

const analysisSchema = {
    type: Type.OBJECT,
    properties: {
        title: { type: Type.STRING, description: "A concise, descriptive title for the code or concept in the image." },
        language_detected: { type: Type.STRING, description: "The programming language or topic detected (e.g., 'Python', 'JavaScript', 'CSS', 'Handwritten Notes')." },
        explanation: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A step-by-step explanation of the code's logic, syntax, and purpose. Each string in the array is a paragraph."
        },
        examples: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    code: { type: Type.STRING, description: "A relevant code example with similar logic or patterns." },
                    comment: { type: Type.STRING, description: "A comment explaining what this example demonstrates." }
                },
                required: ["code", "comment"]
            },
            description: "An array of objects, each containing a code snippet and an explanatory comment."
        },
        scenarios: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Real-world or project scenarios where this code or concept could be applied. Each string is a scenario."
        },
        execution_flow: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "An ordered list describing the execution flow, variable changes, and function calls. Each string is a step."
        },
        summary: { type: Type.STRING, description: "A concise summary of the key takeaways for learning." }
    },
    required: ["title", "language_detected", "explanation", "examples", "scenarios", "execution_flow", "summary"]
};


export const analyzeImage = async (imageDataBase64: string, mimeType: string): Promise<AnalysisResult> => {
    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: imageDataBase64,
                            mimeType: mimeType,
                        },
                    },
                    {
                        text: "Analyze the provided image containing code, handwritten notes, or a diagram. Generate a structured learning output based on the provided JSON schema. Ensure the response is a valid JSON object matching the schema perfectly."
                    }
                ]
            },
            config: {
                responseMimeType: "application/json",
                responseSchema: analysisSchema,
            },
        });

        const jsonString = response.text.trim();
        const result = JSON.parse(jsonString);
        
        // Basic validation
        if (!result.title || !Array.isArray(result.explanation)) {
            throw new Error("Invalid JSON structure received from API.");
        }

        return result as AnalysisResult;

    } catch (error) {
        console.error("Error analyzing image with Gemini:", error);
        throw new Error("Failed to analyze the image. The content may be unclear or there might be an issue with the AI service.");
    }
};

export const simulateCodeExecution = async (code: string, language: string): Promise<string> => {
    try {
        const prompt = `You are a code execution engine. Please execute the following ${language} code and return ONLY the standard output as plain text. If there is an error, return ONLY the standard error message. Do not add any explanations, commentary, or formatting like markdown backticks.

Code:
\`\`\`${language}
${code}
\`\`\``;
        
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
        });

        return response.text;
    } catch (error) {
        console.error("Error simulating code execution:", error);
        throw new Error("Failed to simulate code execution. The AI service may be temporarily unavailable.");
    }
};
