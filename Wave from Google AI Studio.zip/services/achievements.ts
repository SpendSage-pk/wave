import { Achievement, AchievementID, GamificationProfile, HistoryItem } from '../types';
import { TrophyIcon, SparklesIcon, FireIcon } from '../components/Icons';
import React from 'react';

export const ALL_ACHIEVEMENTS: Achievement[] = [
    { id: 'FIRST_SCAN', name: 'First Step', description: 'Analyze your first image.', icon: SparklesIcon },
    { id: 'CURIOUS_LEARNER', name: 'Curious Learner', description: 'Analyze 5 images.', icon: TrophyIcon },
    { id: 'PYTHONISTA', name: 'Pythonista', description: 'Analyze 3 Python snippets.', icon: TrophyIcon },
    { id: 'WEB_WEAVER', name: 'Web Weaver', description: 'Analyze 3 JS/CSS items.', icon: TrophyIcon },
    { id: 'STREAK_3', name: 'On Fire!', description: 'Maintain a 3-day streak.', icon: FireIcon },
    { id: 'STREAK_7', name: 'Week-long Warrior', description: 'Maintain a 7-day streak.', icon: FireIcon },
];

const countByLanguage = (history: HistoryItem[], languages: string[]): number => {
    return history.filter(item => languages.some(lang => item.language_detected.toLowerCase().includes(lang))).length;
};

export const checkAndUnlockAchievements = (history: HistoryItem[], profile: GamificationProfile): AchievementID[] => {
    const newlyUnlocked: AchievementID[] = [];

    const check = (id: AchievementID, condition: boolean) => {
        if (condition && !profile.unlockedAchievements.includes(id)) {
            newlyUnlocked.push(id);
        }
    };

    // History-based achievements
    check('FIRST_SCAN', history.length >= 1);
    check('CURIOUS_LEARNER', history.length >= 5);
    check('PYTHONISTA', countByLanguage(history, ['python']) >= 3);
    check('WEB_WEAVER', countByLanguage(history, ['javascript', 'css', 'html', 'typescript']) >= 3);

    // Profile-based achievements
    check('STREAK_3', profile.streak >= 3);
    check('STREAK_7', profile.streak >= 7);

    return newlyUnlocked;
};
