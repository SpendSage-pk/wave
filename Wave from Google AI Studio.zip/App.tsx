import React, { useState, useEffect } from 'react';
import BottomNav from './components/BottomNav';
import { Tab } from './types';
import HomeScreen from './screens/HomeScreen';
import UploadScreen from './screens/UploadScreen';
import HistoryScreen from './screens/HistoryScreen';
import LearnScreen from './screens/LearnScreen';
import OnboardingScreen from './screens/OnboardingScreen';
import { useLocalStorage } from './hooks/useLocalStorage';
import { ThemeID, THEMES } from './themes';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('Home');
  const [onboardingCompleted, setOnboardingCompleted] = useLocalStorage('wave-onboarding-completed', false);
  const [currentThemeId] = useLocalStorage<ThemeID>('wave-theme', 'default');

  useEffect(() => {
    const body = document.body;
    // Remove all possible theme classes
    THEMES.forEach(theme => {
        if (body.classList.contains(theme.className)) {
            body.classList.remove(theme.className);
        }
    });
    // Add the current theme's class
    const currentTheme = THEMES.find(t => t.id === currentThemeId);
    if (currentTheme) {
        body.classList.add(currentTheme.className);
    } else {
        body.classList.add('theme-default');
    }
  }, [currentThemeId]);

  if (!onboardingCompleted) {
    return <OnboardingScreen onComplete={() => setOnboardingCompleted(true)} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'Home':
        return <HomeScreen setActiveTab={setActiveTab} />;
      case 'Upload':
        return <UploadScreen />;
      case 'History':
        return <HistoryScreen />;
      case 'Learn':
        return <LearnScreen />;
      default:
        return <HomeScreen setActiveTab={setActiveTab} />;
    }
  };

  return (
    <div className="w-full h-screen flex flex-col">
      <main className="flex-1 overflow-y-auto pb-28">
        {renderContent()}
      </main>
      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
};

export default App;
