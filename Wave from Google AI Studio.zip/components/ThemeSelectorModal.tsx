import React from 'react';
import { THEMES, ThemeID } from '../themes';
import { CloseIcon } from './Icons';
import { triggerHapticFeedback } from '../utils/haptics';

interface ThemeSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentThemeId: ThemeID;
  onThemeSelect: (themeId: ThemeID) => void;
}

const ThemeSelectorModal: React.FC<ThemeSelectorModalProps> = ({
  isOpen,
  onClose,
  currentThemeId,
  onThemeSelect,
}) => {
  if (!isOpen) return null;

  const handleSelect = (themeId: ThemeID) => {
    triggerHapticFeedback();
    onThemeSelect(themeId);
  };
  
  const handleClose = () => {
    triggerHapticFeedback();
    onClose();
  }

  return (
    <div
      className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in"
      onClick={handleClose}
    >
      <div
        className="glass-card rounded-3xl w-full max-w-sm text-center p-6 relative transform transition-all animate-bounce-in"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-2 rounded-full text-[var(--text-secondary)] hover:bg-black/10 haptic-press"
        >
          <CloseIcon className="w-5 h-5" />
        </button>

        <h2 className="text-xl font-bold text-[var(--text-primary)] mb-6">Select a Theme</h2>

        <div className="grid grid-cols-2 gap-4">
          {THEMES.map((theme) => (
            <div
              key={theme.id}
              className="flex flex-col items-center cursor-pointer group haptic-press"
              onClick={() => handleSelect(theme.id)}
            >
              <div
                className={`w-full aspect-square rounded-xl mb-2 border-4 transition-all duration-300 ${
                  currentThemeId === theme.id
                    ? 'border-[var(--primary-glow)] scale-105'
                    : 'border-transparent group-hover:border-[var(--accent-glow)]/50'
                }`}
                style={theme.previewStyle}
              ></div>
              <p
                className={`font-semibold text-sm transition-colors ${
                  currentThemeId === theme.id ? 'text-[var(--primary-glow)]' : 'text-[var(--text-secondary)]'
                }`}
              >
                {theme.name}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ThemeSelectorModal;
