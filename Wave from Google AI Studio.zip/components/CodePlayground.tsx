import React, { useState, useEffect, useRef } from 'react';
import { PlayIcon, CloseIcon } from './Icons';
import { triggerHapticFeedback } from '../utils/haptics';
import { simulateCodeExecution } from '../services/geminiService';

declare var hljs: any;

interface CodePlaygroundProps {
  initialCode: string;
  language: string;
  onClose: () => void;
}

const getHljsLanguage = (language: string): string => {
    const lang = language.toLowerCase();
    if (lang.includes('javascript') || lang.includes('js')) return 'javascript';
    if (lang.includes('python')) return 'python';
    if (lang.includes('html')) return 'html';
    if (lang.includes('css')) return 'css';
    if (lang.includes('typescript') || lang.includes('ts')) return 'typescript';
    if (lang.includes('java')) return 'java';
    if (lang.includes('c++') || lang.includes('cpp')) return 'cpp';
    if (lang.includes('c#') || lang.includes('csharp')) return 'csharp';
    return 'plaintext';
}

const CodePlayground: React.FC<CodePlaygroundProps> = ({ initialCode, language, onClose }) => {
  const [code, setCode] = useState(initialCode);
  const [output, setOutput] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);

  const codeRef = useRef<HTMLElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const preRef = useRef<HTMLPreElement>(null);

  useEffect(() => {
    if (codeRef.current) {
        codeRef.current.textContent = code;
        hljs.highlightElement(codeRef.current);
    }
  }, [code]);

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, []);

  const handleScroll = () => {
    if (preRef.current && textareaRef.current) {
        preRef.current.scrollTop = textareaRef.current.scrollTop;
        preRef.current.scrollLeft = textareaRef.current.scrollLeft;
    }
  };

  const handleRunCode = async () => {
    triggerHapticFeedback();
    setOutput([]);
    setError(null);
    setIsExecuting(true);
    
    const normalizedLanguage = language.toLowerCase();

    try {
        if (normalizedLanguage.includes('javascript') || normalizedLanguage.includes('js')) {
            // Native execution for JavaScript
            const capturedLogs: string[] = [];
            const originalConsoleLog = console.log;
            console.log = (...args) => {
                capturedLogs.push(args.map(arg => typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)).join(' '));
            };

            try {
                eval(code);
                setOutput(capturedLogs.length > 0 ? capturedLogs : ["Code executed successfully with no output."]);
            } catch (e: any) {
                setError(e.toString());
            } finally {
                console.log = originalConsoleLog;
            }
        } else {
            // AI-simulated execution for other languages
            const result = await simulateCodeExecution(code, language);
            setOutput([result]);
        }
    } catch (e: any) {
        setError(e.message || "An unexpected error occurred during execution.");
    } finally {
        setIsExecuting(false);
    }
  };


  const handleClose = () => {
    triggerHapticFeedback();
    onClose();
  }

  const editorStyles: React.CSSProperties = {
      fontFamily: 'monospace',
      fontSize: '14px',
      lineHeight: '1.5',
      padding: '1rem',
  };

  return (
    <div className="fixed inset-0 bg-[#282c34] z-50 flex flex-col animate-fade-in">
      <header className="flex-shrink-0 bg-gray-900/30 backdrop-blur-sm border-b border-gray-700 flex justify-between items-center p-3 text-white">
        <h2 className="font-semibold text-lg">Code Playground</h2>
        <button onClick={handleClose} className="p-2 rounded-full hover:bg-gray-700 haptic-press">
          <CloseIcon className="w-6 h-6" />
        </button>
      </header>
      
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        <div className="flex-1 flex flex-col relative">
           <textarea
            ref={textareaRef}
            value={code}
            onChange={(e) => setCode(e.target.value)}
            onScroll={handleScroll}
            className="absolute inset-0 w-full h-full bg-transparent text-transparent caret-white resize-none focus:outline-none z-10"
            style={editorStyles}
            spellCheck="false"
          />
          <pre 
            ref={preRef}
            className="w-full h-full m-0 overflow-auto pointer-events-none" 
            style={editorStyles}
            aria-hidden="true"
           >
            <code ref={codeRef} className={`language-${getHljsLanguage(language)}`}>
                {code}
            </code>
          </pre>
        </div>

        <div className="flex-1 flex flex-col border-t-2 md:border-t-0 md:border-l-2 border-gray-700">
            <div className="flex-shrink-0 bg-gray-900/30 p-3 flex justify-between items-center">
                 <h3 className="font-semibold text-gray-300">Output</h3>
                 <button
                    onClick={handleRunCode}
                    disabled={isExecuting}
                    className="bg-green-500 text-white font-bold py-2 px-4 rounded-lg flex items-center hover:bg-green-600 transition-colors haptic-press disabled:bg-gray-500 disabled:cursor-not-allowed"
                    style={{boxShadow: '0 0 8px rgba(74, 222, 128, 0.5)'}}
                >
                    <PlayIcon className="w-5 h-5 mr-1" />
                    {isExecuting ? 'Running...' : 'Run'}
                </button>
            </div>
            <div className="flex-1 p-4 overflow-y-auto">
                {isExecuting && <p className="text-gray-400 text-sm font-mono animate-pulse">Executing...</p>}
                {error && (
                    <pre className="text-red-400 text-sm whitespace-pre-wrap font-mono">{error}</pre>
                )}
                {output.map((line, index) => (
                    <pre key={index} className="text-gray-300 text-sm whitespace-pre-wrap font-mono">{line}</pre>
                ))}
            </div>
        </div>
      </div>
    </div>
  );
};

export default CodePlayground;