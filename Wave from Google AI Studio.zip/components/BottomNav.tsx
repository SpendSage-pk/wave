import React from 'react';
import { Tab } from '../types';
import { HomeIcon, UploadIcon, HistoryIcon, LearnIcon } from './Icons';
import { triggerHapticFeedback } from '../utils/haptics';

interface BottomNavProps {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
}

const navItems: { name: Tab; icon: React.FC<{ className?: string }> }[] = [
  { name: 'Home', icon: HomeIcon },
  { name: 'Upload', icon: UploadIcon },
  { name: 'History', icon: HistoryIcon },
  { name: 'Learn', icon: LearnIcon },
];

const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab }) => {
  const activeIndex = navItems.findIndex(item => item.name === activeTab);

  return (
    <div className="fixed bottom-0 left-0 right-0 h-24 bg-transparent pointer-events-none">
      <nav className="absolute bottom-4 left-1/2 -translate-x-1/2 w-[95%] max-w-sm h-16 glass-card rounded-2xl flex items-center justify-around pointer-events-auto">
        <div
          className="absolute top-1/2 -translate-y-1/2 left-0 h-12 w-1/4 flex items-center justify-center transition-transform duration-500 ease-[cubic-bezier(0.2,1,0.2,1)]"
          style={{ transform: `translateX(${activeIndex * 100}%)` }}
        >
          <div className="h-12 w-16 bg-teal-100/80 rounded-full" />
        </div>
        {navItems.map((item) => {
          const isActive = activeTab === item.name;
          return (
            <button
              key={item.name}
              onClick={() => {
                triggerHapticFeedback();
                setActiveTab(item.name);
              }}
              className="relative z-10 flex flex-col items-center justify-center w-1/4 h-full transition-colors duration-300 ease-in-out haptic-press"
            >
              <item.icon className={`w-6 h-6 mb-1 transition-colors ${isActive ? 'text-[var(--primary-glow)]' : 'text-gray-500'}`}/>
              <span className={`text-xs font-semibold transition-colors ${isActive ? 'text-[var(--primary-glow)]' : 'text-gray-500'}`}>
                {item.name}
              </span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};

export default BottomNav;