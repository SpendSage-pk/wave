import React from 'react';

interface WeeklyActivityChartProps {
  activityData: Map<string, number>;
}

const WEEKS_TO_SHOW = 7;
const DAYS_IN_WEEK = 7;

const WeeklyActivityChart: React.FC<WeeklyActivityChartProps> = ({ activityData }) => {
  const today = new Date();
  const endDate = new Date(today);
  const startDate = new Date(today);
  startDate.setDate(today.getDate() - (WEEKS_TO_SHOW * DAYS_IN_WEEK - 1));

  const days: Date[] = [];
  for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
    days.push(new Date(d));
  }
  
  const getColor = (count: number) => {
    if (count === 0) return 'bg-gray-200';
    if (count <= 1) return 'bg-[#A5D6A7]';
    if (count <= 3) return 'bg-[#81C784]';
    return 'bg-[#4DB6AC]';
  };

  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <div>
      <div className="grid grid-cols-7 gap-1.5">
        {days.map(date => {
          const dateString = date.toISOString().split('T')[0];
          const count = activityData.get(dateString) || 0;
          return (
            <div
              key={dateString}
              className={`w-full aspect-square rounded-sm ${getColor(count)}`}
              title={`${dateString}: ${count} scan${count !== 1 ? 's' : ''}`}
            />
          );
        })}
      </div>
      <div className="flex justify-end text-xs text-gray-500 mt-2 items-center space-x-2">
          <span>Less</span>
          <div className="w-3 h-3 rounded-sm bg-gray-200"></div>
          <div className="w-3 h-3 rounded-sm bg-[#A5D6A7]"></div>
          <div className="w-3 h-3 rounded-sm bg-[#81C784]"></div>
          <div className="w-3 h-3 rounded-sm bg-[#4DB6AC]"></div>
          <span>More</span>
      </div>
    </div>
  );
};

export default WeeklyActivityChart;
