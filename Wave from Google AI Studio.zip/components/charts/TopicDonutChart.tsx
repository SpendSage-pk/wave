import React from 'react';

interface ChartData {
  label: string;
  value: number;
  color: string;
}

interface TopicDonutChartProps {
  data: ChartData[];
}

const TopicDonutChart: React.FC<TopicDonutChartProps> = ({ data }) => {
  const size = 160;
  const strokeWidth = 20;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const totalValue = data.reduce((sum, item) => sum + item.value, 0);

  let accumulatedPercent = 0;

  if (totalValue === 0) {
    return (
        <div className="flex flex-col items-center justify-center h-full text-center">
            <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
                <circle
                cx={size / 2}
                cy={size / 2}
                r={radius}
                fill="none"
                stroke="#E5E7EB"
                strokeWidth={strokeWidth}
                />
            </svg>
            <p className="text-sm text-gray-500 mt-4">Analyze an image to see your topic focus here!</p>
        </div>
    );
  }

  return (
    <div className="flex flex-col items-center">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="#E5E7EB"
          strokeWidth={strokeWidth}
        />
        {data.map((item, index) => {
          const percent = (item.value / totalValue) * 100;
          const offset = circumference - (accumulatedPercent / 100) * circumference;
          accumulatedPercent += percent;
          return (
            <circle
              key={index}
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="none"
              stroke={item.color}
              strokeWidth={strokeWidth}
              strokeDasharray={circumference}
              strokeDashoffset={offset}
              strokeLinecap="round"
            />
          );
        })}
      </svg>
      <div className="mt-4 w-full space-y-2">
        {data.map((item) => (
          <div key={item.label} className="flex items-center justify-between text-sm">
            <div className="flex items-center">
              <span className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: item.color }}></span>
              <span className="text-gray-600">{item.label}</span>
            </div>
            <span className="font-semibold text-gray-800">
              {Math.round((item.value / totalValue) * 100)}%
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TopicDonutChart;
