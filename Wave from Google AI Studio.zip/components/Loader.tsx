import React from 'react';

const Loader: React.FC<{ message: string }> = ({ message }) => {
  return (
    <div className="flex flex-col items-center justify-center text-center p-8">
      <div className="relative w-20 h-20">
        {[...Array(5)].map((_, i) => (
          <div
            key={i}
            className="absolute w-full h-full rounded-full"
            style={{
              transform: `rotate(${i * 72}deg)`,
              animation: `orbit 3s infinite`,
              animationDelay: `${i * 0.2}s`,
            }}
          >
            <div
              className="absolute top-0 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-[var(--primary-glow)]"
              style={{
                animation: `pulse 1.5s infinite ease-in-out`,
                animationDelay: `${i * 0.2}s`,
              }}
            ></div>
          </div>
        ))}
      </div>
      <p className="mt-6 text-lg font-semibold text-[var(--primary-glow)]">{message}</p>
      <p className="text-sm text-gray-500">This might take a moment...</p>
      <style>{`
        @keyframes orbit {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes pulse {
          0%, 100% { transform: scale(0.6); opacity: 0.8; }
          50% { transform: scale(1); opacity: 1; }
        }
      `}</style>
    </div>
  );
};

export default Loader;