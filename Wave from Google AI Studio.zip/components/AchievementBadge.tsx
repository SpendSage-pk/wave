import React from 'react';
import { Achievement } from '../types';

interface AchievementBadgeProps {
    achievement: Achievement;
    isUnlocked: boolean;
}

const AchievementBadge: React.FC<AchievementBadgeProps> = ({ achievement, isUnlocked }) => {
    const Icon = achievement.icon;
    return (
        <div className={`flex flex-col items-center text-center p-3 rounded-2xl transition-all duration-300 ${isUnlocked ? 'bg-amber-100/60' : 'bg-gray-100'}`}>
            <div className={`w-14 h-14 rounded-full flex items-center justify-center mb-2 ${isUnlocked ? 'bg-amber-400 text-white' : 'bg-gray-200 text-gray-400'}`}>
                <Icon className="w-8 h-8"/>
            </div>
            <h4 className={`font-semibold text-sm ${isUnlocked ? 'text-amber-900' : 'text-gray-600'}`}>{achievement.name}</h4>
            <p className={`text-xs mt-1 ${isUnlocked ? 'text-amber-700' : 'text-gray-400'}`}>{achievement.description}</p>
        </div>
    );
};

export default AchievementBadge;
