import React, { useState } from 'react';
import { triggerHapticFeedback } from '../utils/haptics';

interface CodeBlockProps {
  code: string;
  language: string;
}

const CodeBlock: React.FC<CodeBlockProps> = ({ code, language }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    triggerHapticFeedback();
    navigator.clipboard.writeText(code).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="bg-[#282c34] rounded-xl shadow-md my-4 relative border border-gray-700" style={{boxShadow: '0 0 15px rgba(77, 182, 172, 0.1)'}}>
      <div className="flex justify-between items-center px-4 py-2 bg-gray-700/50 rounded-t-xl">
        <span className="text-xs font-sans text-gray-400 uppercase">{language}</span>
        <button
          onClick={handleCopy}
          className="text-xs text-gray-300 hover:text-white transition-colors flex items-center haptic-press"
        >
          {copied ? (
            <>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              Copied!
            </>
          ) : (
             <>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
                Copy
            </>
          )}
        </button>
      </div>
      <pre className="p-4 text-sm text-white overflow-x-auto">
        <code>{code}</code>
      </pre>
    </div>
  );
};

export default CodeBlock;