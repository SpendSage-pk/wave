import React, { useEffect } from 'react';
import { Achievement } from '../types';
import { TrophyIcon } from './Icons';
import { triggerHapticFeedback } from '../utils/haptics';

interface AchievementUnlockedModalProps {
  achievements: Achievement[];
  onClose: () => void;
}

const AchievementUnlockedModal: React.FC<AchievementUnlockedModalProps> = ({ achievements, onClose }) => {

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => {
        document.body.style.overflow = 'auto';
    };
  }, []);

  if (achievements.length === 0) return null;
  
  const achievement = achievements[0]; // Show one at a time for more impact
  const Icon = achievement.icon;

  const handleClose = () => {
    triggerHapticFeedback();
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in">
      <div className="glass-card rounded-3xl w-full max-w-sm text-center p-8 relative transform transition-all animate-bounce-in">
        <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-24 h-24 bg-gradient-to-br from-amber-400 to-orange-500 rounded-full flex items-center justify-center border-4 border-white shadow-lg">
          <TrophyIcon className="w-12 h-12 text-white" />
        </div>
        
        <h2 className="text-2xl font-bold text-gray-800 mt-12">Achievement Unlocked!</h2>
        <p className="text-gray-500 mt-1">You've earned a new badge!</p>

        <div className="bg-amber-50 border-2 border-amber-200 rounded-2xl p-4 my-6 flex flex-col items-center">
             <div className="w-16 h-16 rounded-full flex items-center justify-center bg-amber-400 text-white mb-3">
                <Icon className="w-9 h-9"/>
            </div>
            <h3 className="font-bold text-lg text-amber-900">{achievement.name}</h3>
            <p className="text-sm text-amber-800">{achievement.description}</p>
        </div>

        <button
          onClick={handleClose}
          className="w-full bg-gradient-to-r from-[#4DB6AC] to-[#81C784] text-white font-bold py-3 px-6 rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-300 haptic-press"
        >
          Continue
        </button>
      </div>
    </div>
  );
};

export default AchievementUnlockedModal;