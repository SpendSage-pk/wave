import React from 'react';

export type Tab = 'Home' | 'Upload' | 'History' | 'Learn';

export interface AnalysisResult {
  title: string;
  language_detected: string;
  explanation: string[];
  examples: {
    code: string;
    comment: string;
  }[];
  scenarios: string[];
  execution_flow: string[];
  summary: string;
}

export interface HistoryItem extends AnalysisResult {
  id: string;
  timestamp: string;
  imagePreview: string;
  feedback?: 'like' | 'dislike';
  feedbackComment?: string;
}

// Gamification Types
export type AchievementID = 'FIRST_SCAN' | 'CURIOUS_LEARNER' | 'PYTHONISTA' | 'WEB_WEAVER' | 'STREAK_3' | 'STREAK_7';

export interface Achievement {
    id: AchievementID;
    name: string;
    description: string;
    icon: React.FC<{className?: string}>;
}

export interface UnlockedAchievementInfo extends Achievement {
    isNew: boolean;
}

export interface GamificationProfile {
    totalXP: number;
    streak: number;
    lastActiveDate: string | null; // ISO Date string (YYYY-MM-DD)
    unlockedAchievements: AchievementID[];
}
