export type ThemeID = 'default' | 'ocean' | 'neon' | 'mint';

export interface Theme {
    id: ThemeID;
    name: string;
    className: string;
    previewStyle: React.CSSProperties;
}

export const THEMES: Theme[] = [
    {
        id: 'default',
        name: 'Pastel Glass',
        className: 'theme-default',
        previewStyle: { background: 'linear-gradient(135deg, #f2fdfb, #f4f8f3)' },
    },
    {
        id: 'ocean',
        name: 'Ocean Waves',
        className: 'theme-ocean-waves',
        previewStyle: { background: 'linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab)' },
    },
    {
        id: 'neon',
        name: 'Neon Grid',
        className: 'theme-neon-grid',
        previewStyle: {
            backgroundColor: '#0d0d1a',
            backgroundImage: `
                linear-gradient(rgba(12, 114, 224, 0.5) 1px, transparent 1px),
                linear-gradient(90deg, rgba(12, 114, 224, 0.5) 1px, transparent 1px)
            `,
            backgroundSize: '20px 20px',
        },
    },
    {
        id: 'mint',
        name: 'Static Mint',
        className: 'theme-static-mint',
        previewStyle: { background: 'linear-gradient(135deg, #e6fffa, #f0fdf4)' },
    },
];
