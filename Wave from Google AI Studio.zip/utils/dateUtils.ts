export const getISODateString = (date: Date): string => {
    return date.toISOString().split('T')[0];
};

export const isToday = (isoDateString: string): boolean => {
    return isoDateString === getISODateString(new Date());
};

export const isYesterday = (isoDateString: string): boolean => {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    return isoDateString === getISODateString(yesterday);
};
