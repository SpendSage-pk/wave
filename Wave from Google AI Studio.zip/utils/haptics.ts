/**
 * Triggers a short haptic feedback vibration if the device supports it.
 * This provides a tactile response for user interactions.
 */
export const triggerHapticFeedback = () => {
  if (typeof window !== 'undefined' && 'vibrate' in navigator) {
    // A short 10ms vibration provides a light tap sensation
    navigator.vibrate(10);
  }
};
