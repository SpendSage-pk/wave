import { HistoryItem } from '../types';
import { getISODateString } from './dateUtils';

export const processHistoryForActivityChart = (history: HistoryItem[]): Map<string, number> => {
    const activityMap = new Map<string, number>();
    history.forEach(item => {
        const dateStr = getISODateString(new Date(item.timestamp));
        activityMap.set(dateStr, (activityMap.get(dateStr) || 0) + 1);
    });
    return activityMap;
};
